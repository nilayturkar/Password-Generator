import { useCallback, useEffect, useRef, useState } from 'react'
import './App.css'

export default function App() {
  let[length,setlength]=useState(5)
  let[num,setnum]=useState(false)
  let[char,setchar]=useState(false)
  let[pass,setpass]=useState("")
  let passWordGen=useRef(null)

  let passGen=useCallback(()=>{
    let password =''
    let string='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    if(num) string+='0123456789'
     if(char) string+='!@#$%^&*-_+=[]{}~'

     for(let i=0;i<length;i++){
      let gen=Math.floor(Math.random()*string.length)
      password+=string.charAt(gen)
      console.log(gen);
      
     }

     setpass(password)



  },[length,num,char])
  let copyText=useCallback(()=>{
    passWordGen.current?.select()
    passWordGen.current?.setSelectionRange(0,10)
    window.navigator.clipboard.writeText(pass)

  },[pass])

  useEffect(()=>{passGen()


  },[length,num,char,setpass,passGen])


  return (
    <>
    <div className='w-full max-w-md mx-auto shadow-md rounded-lg px-4 py-3 my-8 bg-gray-800 text-black-500'>
    <h1 className='text-3xl text-center text-white'>PASSgen</h1>
    <div className='flex shadow rounded-lg overflow-hidden mb-4'>
      <input type="text" value={pass} className='outline-none w-full py-1 px-3' placeholder='Password ' readOnly ref={passWordGen}/>
      <button onClick={copyText} className='outline-none bg-green-500 text-white px-3 py-0.5 shrink-0' >copy</button>
    </div>
   

    <div className='flex text-sm gap-x-2'>
      <div className='flex items-center gap-x-1'>
        <input type="range" min={5} max={100} className='cursor-pointer' onChange={(e)=>{setlength(e.target.value)}} />

        <label htmlFor="">length:{length}</label>
      </div>
      <div className='flex items-center gap-x-1'>
        <input type="checkbox" defaultChecked={num} id='numberInput' onChange={()=>{
          setnum((prev)=>!prev)
        }} />
        <label htmlFor="numberInput">Number</label>
        
      </div>
      <div className='flex items-center gap-x-1'>
        <input type="checkbox" defaultChecked={char} id='characterInput' onChange={()=>{
          setchar((prev)=>!prev)
        }} />
        <label htmlFor="characterInput">Character</label>
        
      </div>
    </div>
    </div>

    </>
   )

  }
 

  